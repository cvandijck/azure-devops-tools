# Test Data

This data folder is used to store all data to test the adopt package.

The content of this data folder can be ignored by git (added to .gitignore) to keep source tracking efficient. The application data can be pulled from another data repository, e.g. via git LFS.
