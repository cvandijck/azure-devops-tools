API Reference
=================================

Contents
---------

.. toctree::
    :maxdepth: 1

    _generated/adopt

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

